# !!!PLEASE READ!!!

## Questions

If you have a question, DO NOT SUBMIT a new issue.  Please ask the question on the Q&A Group: https://groups.google.com/forum/#!forum/nginx-proxy

## Bugs or Features

If you are logging a bug or feature request, please search the current open issues to see if there is already a bug or feature opened.

For bugs, the easier you make it to reproduce the issue you see, the easier and faster it can get fixed.  If you can provide a script or docker-compose file that reproduces the problems, that is very helpful.

Thanks,
Jason
